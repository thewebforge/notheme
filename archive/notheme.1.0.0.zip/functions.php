<?php
    // Silence is golden
